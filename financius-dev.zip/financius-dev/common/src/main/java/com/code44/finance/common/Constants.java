package com.code44.finance.common;

public class Constants {
    public static final String WEB_CLIENT_ID = "1007413878843-5t32vfui2r35ufc56usmicfnnfkt3h1u.apps.googleusercontent.com";
    public static final String ANDROID_AUDIENCE = WEB_CLIENT_ID;
    public static final String ANDROID_CLIENT_ID = "1007413878843-suhpr9i0apd98bd8louuvs6g3p9nc8vk.apps.googleusercontent.com";
    public static final String IOS_CLIENT_ID = "3-ios-apps.googleusercontent.com";
    public static final String EMAIL_SCOPE = "https://www.googleapis.com/auth/userinfo.email";
}
