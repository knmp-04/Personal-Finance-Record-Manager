package com.code44.finance.ui.dialogs;

import android.app.DialogFragment;

public class IntervalDialogFragment extends DialogFragment {

}
