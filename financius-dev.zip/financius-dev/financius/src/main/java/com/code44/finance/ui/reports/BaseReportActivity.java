package com.code44.finance.ui.reports;

import com.code44.finance.ui.common.activities.BaseDrawerActivity;

public abstract class BaseReportActivity extends BaseDrawerActivity {
}
