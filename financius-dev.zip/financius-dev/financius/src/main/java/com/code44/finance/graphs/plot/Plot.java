package com.code44.finance.graphs.plot;

public class Plot {
}
