package com.code44.finance.graphs;

public interface GraphValue {
    public double getValue();

    public abstract String getFormattedValue();
}
